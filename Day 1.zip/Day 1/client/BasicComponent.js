 import React from 'react';
import CommentComponent from './Comments';


 export default  class BlogComponent extends React.Component{
     constructor(){
         super();
         this.Message = "First Comment !";
         this.Message2 = "Second Comment !";
     }
        render(){
            return (<div> 
                    <h1>Header ! </h1>
                    <CommentComponent firstComment={this.Message} /> 
                    <CommentComponent firstComment={this.Message2} /> 
                
                    
                  </div>)
        }
    }

