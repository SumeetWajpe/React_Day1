import React from 'react';
import ReactDOM from 'react-dom';

import ButtonComponent from './CustomButton';

export default class ButtonList extends React.Component{
    constructor(props){
        super(props);        
    }
    componentWillMount(){
        this.state = {list:[20,30,100,400]};
        console.log('componentWillMount..')
    }
     componentDidMount(){        
        console.log('componentDidMount..')
    }
    shouldComponentUpdate(){
        console.log('shouldComponentUpdate..')
        return true;
    }
    componentWillUpdate(){
        console.log('componentWillUpdate..')
    }
     componentDidUpdate(){
        console.log('componentDidUpdate..')        
    }
    AddButtonHandler(){
        console.log('AddButtonHandler (setState)..')
        
        var txtData =    ReactDOM.findDOMNode(this.refs.inputData).value;

        this.setState({list:[...this.state.list,+(txtData)]});

    }

    render(){
        console.log('render..')
        var buttonsToBcreated = this.state.list.map((val,index)=>{
            return <ButtonComponent key={index} InitialCount={val} />
        });

        return<div>

            Enter Value : <input ref="inputData" type="text" /> <input type="button" value="Add" className="btn btn-success btn-sm" onClick={this.AddButtonHandler.bind(this)} />

             {buttonsToBcreated}
             </div>
    }
}