import React from 'react';

export default class CommentComponent extends React.Component{
    render(){
        return<div>
             <b> {this.props.firstComment} </b><br/> 
             </div>
    }
}