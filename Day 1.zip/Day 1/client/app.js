// Code Here

import React from 'react';
import ReactDOM from 'react-dom';
import BlogComponent from './BasicComponent';
import ButtonList from './ButtonList';
import UsersComponent from './Users';


ReactDOM.render(<UsersComponent />,document.getElementById('content'))